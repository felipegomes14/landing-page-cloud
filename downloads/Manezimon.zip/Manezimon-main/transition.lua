local transition = {}

transition.alpha = 0
transition.active = false
transition.coroutine = nil

function transition.start(func)

    transition.active = true

    transition.coroutine = coroutine.create(func)
    coroutine.resume(transition.coroutine)

end

function transition.fadeIn(speed)

    while transition.alpha < 1 do

        transition.alpha =
            math.min(
                1,
                transition.alpha + speed
            )

        coroutine.yield()
    end
end

function transition.fadeOut(speed)

    while transition.alpha > 0 do

        transition.alpha =
            math.max(
                0,
                transition.alpha - speed
            )

        coroutine.yield()
    end

    transition.active = false
end

function transition.update()

    if transition.coroutine and
       coroutine.status(transition.coroutine) ~= "dead" then

        coroutine.resume(transition.coroutine)
    end
end

function transition.draw()

    if transition.alpha <= 0 then
        return
    end

    local w = love.graphics.getWidth()
    local h = love.graphics.getHeight()

    love.graphics.setColor(0,0,0,transition.alpha)
    love.graphics.rectangle("fill",0,0,w,h)

    love.graphics.setColor(1,1,1)
end

return transition